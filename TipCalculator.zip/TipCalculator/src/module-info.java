/**
 * 
 */
/**
 * 
 */
module TipCalculator {
	requires java.desktop;
}